#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

double log_s(double x)
{
    float y = 1 / (1 + exp(-x));
    return y;
}
int main()
{

    ifstream in;
    ofstream out;
    
    int i, j, k, p, L, M, N, Q;

    L = 5, M = (2 * L - 1), N = 3, Q = 4;

    double I[L][Q], V[L + 1][M], W[M + 1][N], Imax, Imin, sum, IH[M][Q], OH[M][Q], IO[N][Q], OO[N][Q], Tmax, Tmin, T[N][Q];
    in.open("final_v.txt");
    for (i = 0; i < L + 1; i++)
    {
        for (j = 0; j < M; j++)
        {
            in >> V[i][j];
        }
    }
    in.close();

    in.open("final_w.txt");
    for (i = 0; i < M + 1; i++)
    {
        for (j = 0; j < N; j++)
        {
            in >> W[i][j];
        }
    }

    in.close();

    // input for the input layer//
    in.open("input_data_testing.txt");
     for (i = 0; i < L; i++)
    {
        for (p = 0; p < Q; p++)
        {
            in >> I[i][p];
        }
    }
    in.close();
//normalising input data
    for (i = 0; i < L; i++)
    {

        Imax = I[i][0];
        Imin = I[i][0];
        for (p = 0; p < Q; p++)
        {
            if (I[i][p] > Imax)
            {
                Imax = I[i][p];
            }
            if (I[i][p] < Imin)
            {
                Imin = I[i][p];
            }
        }

        for (p = 0; p < Q; p++)
        {
            I[i][p] = 0.1 + 0.8 * ((I[i][p] - Imin) / (Imax - Imin));
        }
    }
    cout << "input after normalization:" << endl;
    for (i = 0; i < L; i++)
    {
        for (p = 0; p < Q; p++)
        {
            cout << I[i][p] << " ";
        }
        cout << endl;
    }

    in.open("target_data_testing.txt");
    for (k = 0; k < N; k++)
    {
        for (p = 0; p < Q; p++)
        {
            in >> T[k][p];
        }
    }
    in.close();
    



    for (p = 0; p < Q; p++)
    {
        for (j = 0; j < M; j++)
        {
            sum = 0;
            IH[j][p] = 0;
            for (i = 0; i < L; i++)
            {
                sum = sum + I[i][p] * V[i][j];
            }
            IH[j][p] = sum + 1 * V[L][j];
        }
    }

    // outpot for Hidden neuron//
    for (p = 0; p < Q; p++)
    {
        for (j = 0; j < M; j++)
        {
            OH[j][p] = log_s(IH[j][p]);
        }
    }

    for (p = 0; p < Q; p++)
    {
        for (k = 0; k < N; k++)
        {
            sum = 0;
            IO[k][p] = 0;
            for (j = 0; j < M; j++)
            {
                sum = sum + OH[j][p] * W[j][k];
            }
            IO[k][p] = sum + 1 * W[M + 1][k];
        }
    }
    // outpot for output neuron//
    for (p = 0; p < Q; p++)
    {
        for (k = 0; k < N; k++)
        {
            OO[k][p] = log_s(IO[k][p]);
        }
    }

    cout << "output of output neuron is:" << endl;

    for (p = 0; p < Q; p++)
    {
        for (k = 0; k < N; k++)
        {
            cout << OO[k][p] << " ";
        }
        cout << endl;
    }

    // predicted output after denormalisation//

    for (k = 0; k < N; k++)
    {

        Tmax = T[k][0];
        Tmin = T[k][0];
        for (p = 0; p < Q; p++)
        {
            Tmax = max(Tmax, T[k][p]);
            Tmin = min(Tmin, T[k][p]);
        }

        for (p = 0; p < Q; p++)
        {
            OO[k][p] = Tmin + ((OO[k][p] - 0.1) / (0.8)) * (Tmax - Tmin);
        }
    }

    cout << "predicted output after de-normalization:" << endl;

    for (k = 0; k < N; k++)
    {
        for (p = 0; p < Q; p++)
        {
            cout << OO[k][p] << " ";
        }
        cout << endl;
    }
    cout<<"the exact outpout is:"<<endl;
    for (k = 0; k < N; k++)
    {
        for (p = 0; p < Q; p++)
        {
            cout<< T[k][p]<<" ";
        }
        cout<<endl;
    }

    return 0;
}